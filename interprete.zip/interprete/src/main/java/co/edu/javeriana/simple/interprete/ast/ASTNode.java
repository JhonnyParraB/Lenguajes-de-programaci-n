package co.edu.javeriana.simple.interprete.ast;

public interface ASTNode {
	public Object execute();

}
