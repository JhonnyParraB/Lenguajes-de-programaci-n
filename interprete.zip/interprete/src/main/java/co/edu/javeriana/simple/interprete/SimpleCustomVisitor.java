
package co.edu.javeriana.simple.interprete;

public class SimpleCustomVisitor extends SimpleBaseVisitor<Object> {



}
